<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Inertia\Inertia;
use Illuminate\Support\Str;

class PostController extends Controller
{
    /**
     * Display a listing of posts and categories.
     */
    public function index()
    {
        return Inertia::render('Admin/Posts/Index', [
            'posts' => Post::with('category')->latest()->get(),
            'categories' => Category::withCount('posts')->get()
        ]);
    }

    /**
     * Show the form for creating a new post.
     */
    public function create()
    {
        return Inertia::render('Admin/Posts/CreateEdit', [
            'categories' => Category::all()
        ]);
    }

    /**
     * Store a newly created post in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'category_id' => 'required|exists:categories,id',
            'title' => 'required|string|max:150',
            'slug' => 'required|string|max:150|unique:posts,slug',
            'content' => 'required|string',
            'image' => 'nullable|image|mimes:png,jpg,jpeg,webp|max:2048',
            'status' => 'required|in:draft,published',
            'is_featured' => 'required|boolean',
        ]);

        $validated['slug'] = Str::slug($validated['slug']);

        if ($request->hasFile('image')) {
            $dir = public_path('uploads/posts');
            if (!is_dir($dir)) {
                mkdir($dir, 0755, true);
            }
            $file = $request->file('image');
            $filename = Str::slug($validated['title']) . '-' . time() . '.' . $file->getClientOriginalExtension();
            $file->move($dir, $filename);
            $validated['image'] = '/uploads/posts/' . $filename;
        }

        Post::create($validated);

        return redirect()->route('admin.posts.index')->with('success', 'Postingan baru berhasil ditambahkan.');
    }

    /**
     * Show the form for editing the specified post.
     */
    public function edit(Post $post)
    {
        return Inertia::render('Admin/Posts/CreateEdit', [
            'post' => $post,
            'categories' => Category::all()
        ]);
    }

    /**
     * Update the specified post in storage.
     */
    public function update(Request $request, Post $post)
    {
        // Support standard PUT/PATCH file upload emulation in Inertia
        // (Inertia handles file uploads via POST. For updates, we often send POST with _method=PUT)
        $validated = $request->validate([
            'category_id' => 'required|exists:categories,id',
            'title' => 'required|string|max:150',
            'slug' => 'required|string|max:150|unique:posts,slug,' . $post->id,
            'content' => 'required|string',
            'image' => 'nullable|image|mimes:png,jpg,jpeg,webp|max:2048',
            'status' => 'required|in:draft,published',
            'is_featured' => 'required|boolean',
        ]);

        $validated['slug'] = Str::slug($validated['slug']);

        if ($request->hasFile('image')) {
            $dir = public_path('uploads/posts');
            if (!is_dir($dir)) {
                mkdir($dir, 0755, true);
            }
            $file = $request->file('image');
            $filename = Str::slug($validated['title']) . '-' . time() . '.' . $file->getClientOriginalExtension();
            $file->move($dir, $filename);
            $validated['image'] = '/uploads/posts/' . $filename;
        } else {
            // Keep original image
            unset($validated['image']);
        }

        $post->update($validated);

        return redirect()->route('admin.posts.index')->with('success', 'Postingan berhasil diperbarui.');
    }

    /**
     * Remove the specified post from storage.
     */
    public function destroy(Post $post)
    {
        if ($post->image && Storage::disk('public')->exists($post->image)) {
            Storage::disk('public')->delete($post->image);
        }
        $post->delete();

        return redirect()->route('admin.posts.index')->with('success', 'Postingan berhasil dihapus.');
    }

    /**
     * Store a category.
     */
    public function storeCategory(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:50|unique:categories,name',
        ]);

        Category::create([
            'name' => $validated['name'],
            'slug' => Str::slug($validated['name']),
        ]);

        return redirect()->back()->with('success', 'Kategori baru berhasil ditambahkan.');
    }

    /**
     * Delete a category.
     */
    public function destroyCategory(Category $category)
    {
        $category->delete();
        return redirect()->back()->with('success', 'Kategori berhasil dihapus.');
    }
}
